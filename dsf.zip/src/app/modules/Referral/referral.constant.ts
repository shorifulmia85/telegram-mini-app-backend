export const referralSearchableField = ["referrerId", "codeUsed"];
