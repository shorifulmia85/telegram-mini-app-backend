import { Types } from "mongoose";

export enum TaskStatus {
  DRAFT = "DRAFT",
  ACTIVE = "ACTIVE",
  PAUSED = "PAUSED",
  ENDED = "ENDED",
}
export enum AdNetwork {
  NONE = "NONE",
  MONETAG = "MONETAG",
  ADSGRAM = "ADSGRAM",
  ONCLICKA = "ONCLICKA",
  GIGAPUB = "GIGAPUB",
}
export enum TaskType {
  VIEW = "VIEW",
  CLICK = "CLICK",
  WATCH_THEN_CLICK = "WATCH_THEN_CLICK",
  VISIT_AND_STAY = "VISIT_EARN",
}

export interface ITask {
  _id?: Types.ObjectId;
  title: string;
  description?: string;
  imageUrl?: string;
  type: TaskType;
  adNetwork: AdNetwork;
  adUnitId: string;
  rewardCoin: number;
  cooldownSec: number;
  perUserCap: number;
  status: TaskStatus;
}
