export interface ISpin {
  value: string;
  bgColor: string;
  textColor: string;
  coin: number;
  active: boolean;
  weight: number;
  segmentIndex: number;
}
